# SolFlux - Solana Wallet

A self-custody Solana wallet built with Expo (React Native).

## Features
- Create new wallet (BIP39 mnemonic, 12 words)
- Import wallet via seed phrase or private key
- View SOL balance (Mainnet)
- Send SOL to any address
- Receive SOL (copyable address + visual grid)
- Transaction history (last 20 txs)
- Keys stored encrypted via expo-secure-store

## Setup

```bash
cd solana-wallet
npm install
```

## Run in Dev

```bash
npx expo start
# Scan QR with Expo Go app on your phone
```

## Build APK (via EAS)

```bash
# Install EAS CLI
npm install -g eas-cli

# Login to Expo account
eas login

# Build APK (preview profile)
eas build --platform android --profile preview
```

EAS will build in the cloud and give you a download link for the APK.

## Build locally (Termux/Linux)

```bash
# Requires Android SDK + Java
npx expo prebuild --platform android
cd android
./gradlew assembleRelease
# APK at: android/app/build/outputs/apk/release/app-release.apk
```

## Switch to Devnet (for testing)

In `context/WalletContext.js`, change:
```js
const RPC_ENDPOINT = 'https://api.mainnet-beta.solana.com';
// to:
const RPC_ENDPOINT = 'https://api.devnet.solana.com';
```

Then airdrop test SOL:
```bash
solana airdrop 2 <YOUR_ADDRESS> --url devnet
```

## Add Real QR Codes

```bash
npm install react-native-qrcode-svg react-native-svg
```

Then in ReceiveScreen.js:
```jsx
import QRCode from 'react-native-qrcode-svg';
<QRCode value={address} size={200} color="#14F195" backgroundColor="#080B14" />
```

## Stack
- Expo ~50
- @solana/web3.js
- bip39 + tweetnacl + ed25519-hd-key (HD wallet derivation)
- expo-secure-store (encrypted key storage)
- expo-linear-gradient
- React Navigation v6
