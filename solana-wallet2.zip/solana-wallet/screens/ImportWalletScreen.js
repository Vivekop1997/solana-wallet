import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  ScrollView, Alert, ActivityIndicator, Dimensions, KeyboardAvoidingView, Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useWallet } from '../context/WalletContext';

const { width } = Dimensions.get('window');

export default function ImportWalletScreen({ navigation }) {
  const { importWallet, importFromPrivateKey, loading } = useWallet();
  const [mode, setMode] = useState('mnemonic'); // mnemonic | privatekey
  const [input, setInput] = useState('');

  const handleImport = async () => {
    if (!input.trim()) {
      Alert.alert('Error', 'Please enter your seed phrase or private key');
      return;
    }
    try {
      if (mode === 'mnemonic') {
        await importWallet(input.trim());
      } else {
        await importFromPrivateKey(input.trim());
      }
      navigation.replace('Dashboard');
    } catch (e) {
      Alert.alert('Import Failed', e.message);
    }
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <View style={styles.container}>
        <LinearGradient colors={['#080B14', '#0D1628', '#080B14']} style={StyleSheet.absoluteFill} />

        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
            <Text style={styles.backText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Import Wallet</Text>
          <View style={{ width: 60 }} />
        </View>

        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
          <View style={styles.iconBadge}>
            <Text style={styles.iconText}>📥</Text>
          </View>
          <Text style={styles.title}>Restore Your Wallet</Text>
          <Text style={styles.subtitle}>Import using your seed phrase or private key.</Text>

          {/* Mode toggle */}
          <View style={styles.toggle}>
            <TouchableOpacity
              style={[styles.toggleBtn, mode === 'mnemonic' && styles.toggleActive]}
              onPress={() => { setMode('mnemonic'); setInput(''); }}
            >
              <Text style={[styles.toggleText, mode === 'mnemonic' && styles.toggleTextActive]}>
                Seed Phrase
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.toggleBtn, mode === 'privatekey' && styles.toggleActive]}
              onPress={() => { setMode('privatekey'); setInput(''); }}
            >
              <Text style={[styles.toggleText, mode === 'privatekey' && styles.toggleTextActive]}>
                Private Key
              </Text>
            </TouchableOpacity>
          </View>

          <TextInput
            style={styles.input}
            value={input}
            onChangeText={setInput}
            placeholder={
              mode === 'mnemonic'
                ? 'Enter your 12 or 24 word seed phrase...'
                : 'Enter base58 private key...'
            }
            placeholderTextColor="#3A4A63"
            multiline={mode === 'mnemonic'}
            numberOfLines={mode === 'mnemonic' ? 4 : 1}
            autoCapitalize="none"
            autoCorrect={false}
            secureTextEntry={mode === 'privatekey'}
          />

          <View style={styles.securityNote}>
            <Text style={styles.securityText}>
              🔒 Your key is stored encrypted on this device only. Never transmitted.
            </Text>
          </View>

          <TouchableOpacity onPress={handleImport} disabled={loading} activeOpacity={0.85}>
            <LinearGradient
              colors={['#9945FF', '#14F195']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.primaryBtn}
            >
              {loading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text style={styles.primaryBtnText}>Import Wallet</Text>
              )}
            </LinearGradient>
          </TouchableOpacity>
        </ScrollView>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#080B14' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 56,
    paddingBottom: 16,
  },
  backBtn: { padding: 8 },
  backText: { color: '#7A90B8', fontSize: 15 },
  headerTitle: { color: '#fff', fontSize: 17, fontWeight: '700' },
  content: { paddingHorizontal: 24, paddingBottom: 40, alignItems: 'center' },
  iconBadge: {
    width: 80, height: 80, borderRadius: 24,
    backgroundColor: '#111827', alignItems: 'center', justifyContent: 'center',
    marginBottom: 24, borderWidth: 1, borderColor: '#1E2D4A',
  },
  iconText: { fontSize: 36 },
  title: { color: '#fff', fontSize: 24, fontWeight: '800', marginBottom: 12, textAlign: 'center' },
  subtitle: { color: '#6B7FA3', fontSize: 14, textAlign: 'center', lineHeight: 22, marginBottom: 28 },
  toggle: {
    flexDirection: 'row',
    backgroundColor: '#111827',
    borderRadius: 12,
    padding: 4,
    width: '100%',
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#1E2D4A',
  },
  toggleBtn: {
    flex: 1, paddingVertical: 10, alignItems: 'center', borderRadius: 10,
  },
  toggleActive: { backgroundColor: '#1E2D4A' },
  toggleText: { color: '#4A5B7A', fontWeight: '600', fontSize: 14 },
  toggleTextActive: { color: '#E0EAFF' },
  input: {
    width: '100%',
    backgroundColor: '#111827',
    borderRadius: 14,
    padding: 16,
    color: '#E0EAFF',
    fontSize: 14,
    borderWidth: 1.5,
    borderColor: '#1E2D4A',
    marginBottom: 16,
    lineHeight: 22,
    textAlignVertical: 'top',
    minHeight: 56,
  },
  securityNote: {
    width: '100%',
    backgroundColor: '#0A1628',
    borderRadius: 12,
    padding: 14,
    borderWidth: 1,
    borderColor: '#1A2E50',
    marginBottom: 28,
  },
  securityText: { color: '#5A7FA0', fontSize: 13, lineHeight: 18, textAlign: 'center' },
  primaryBtn: {
    width: width - 48, paddingVertical: 16, borderRadius: 14, alignItems: 'center',
  },
  primaryBtnText: { color: '#fff', fontWeight: '800', fontSize: 16 },
});
