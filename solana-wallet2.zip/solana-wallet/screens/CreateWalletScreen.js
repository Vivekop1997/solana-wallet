import React, { useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet,
  ScrollView, Alert, ActivityIndicator, Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import * as Clipboard from 'expo-clipboard';
import { useWallet } from '../context/WalletContext';

const { width } = Dimensions.get('window');

export default function CreateWalletScreen({ navigation }) {
  const { createWallet, loading } = useWallet();
  const [step, setStep] = useState('intro'); // intro | mnemonic | confirm
  const [mnemonic, setMnemonic] = useState(null);
  const [copied, setCopied] = useState(false);

  const handleCreate = async () => {
    try {
      const mn = await createWallet();
      setMnemonic(mn);
      setStep('mnemonic');
    } catch (e) {
      Alert.alert('Error', e.message);
    }
  };

  const handleCopy = async () => {
    await Clipboard.setStringAsync(mnemonic);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const words = mnemonic ? mnemonic.split(' ') : [];

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#080B14', '#0D1628', '#080B14']} style={StyleSheet.absoluteFill} />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>
          {step === 'intro' ? 'New Wallet' : 'Seed Phrase'}
        </Text>
        <View style={{ width: 60 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {step === 'intro' && (
          <>
            <View style={styles.iconBadge}>
              <Text style={styles.iconText}>🔐</Text>
            </View>
            <Text style={styles.title}>Create Your Wallet</Text>
            <Text style={styles.subtitle}>
              We'll generate a 12-word seed phrase that gives you full control over your wallet.
            </Text>

            <View style={styles.warningBox}>
              <Text style={styles.warningTitle}>⚠️ Before You Continue</Text>
              {[
                'Write down your seed phrase on paper',
                'Never share it with anyone — ever',
                'Losing it means losing your funds',
                'No recovery without the seed phrase',
              ].map((w, i) => (
                <Text key={i} style={styles.warningItem}>• {w}</Text>
              ))}
            </View>

            <TouchableOpacity onPress={handleCreate} disabled={loading} activeOpacity={0.85}>
              <LinearGradient
                colors={['#9945FF', '#14F195']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.primaryBtn}
              >
                {loading ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <Text style={styles.primaryBtnText}>Generate Seed Phrase</Text>
                )}
              </LinearGradient>
            </TouchableOpacity>
          </>
        )}

        {step === 'mnemonic' && mnemonic && (
          <>
            <Text style={styles.title}>Your Seed Phrase</Text>
            <Text style={styles.subtitle}>
              Write these 12 words in order and store them safely offline.
            </Text>

            {/* Word grid */}
            <View style={styles.wordGrid}>
              {words.map((word, i) => (
                <View key={i} style={styles.wordCard}>
                  <Text style={styles.wordNum}>{i + 1}</Text>
                  <Text style={styles.wordText}>{word}</Text>
                </View>
              ))}
            </View>

            <TouchableOpacity style={styles.copyBtn} onPress={handleCopy} activeOpacity={0.7}>
              <Text style={styles.copyBtnText}>{copied ? '✓ Copied!' : 'Copy to Clipboard'}</Text>
            </TouchableOpacity>

            <View style={styles.dangerBox}>
              <Text style={styles.dangerText}>
                🚨 Never screenshot or save this digitally. Anyone with these words can drain your wallet.
              </Text>
            </View>

            <TouchableOpacity
              onPress={() => navigation.replace('Dashboard')}
              activeOpacity={0.85}
              style={{ width: '100%' }}
            >
              <LinearGradient
                colors={['#9945FF', '#14F195']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.primaryBtn}
              >
                <Text style={styles.primaryBtnText}>I've Saved My Phrase →</Text>
              </LinearGradient>
            </TouchableOpacity>
          </>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#080B14' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 56,
    paddingBottom: 16,
  },
  backBtn: { padding: 8 },
  backText: { color: '#7A90B8', fontSize: 15 },
  headerTitle: { color: '#fff', fontSize: 17, fontWeight: '700' },
  content: { paddingHorizontal: 24, paddingBottom: 40, alignItems: 'center' },
  iconBadge: {
    width: 80,
    height: 80,
    borderRadius: 24,
    backgroundColor: '#111827',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 24,
    borderWidth: 1,
    borderColor: '#1E2D4A',
  },
  iconText: { fontSize: 36 },
  title: { color: '#fff', fontSize: 24, fontWeight: '800', marginBottom: 12, textAlign: 'center' },
  subtitle: { color: '#6B7FA3', fontSize: 14, textAlign: 'center', lineHeight: 22, marginBottom: 28 },
  warningBox: {
    width: '100%',
    backgroundColor: '#111827',
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: '#2A1F4A',
    marginBottom: 32,
    gap: 8,
  },
  warningTitle: { color: '#FFAA00', fontWeight: '700', fontSize: 14, marginBottom: 8 },
  warningItem: { color: '#A0B0CC', fontSize: 13, lineHeight: 20 },
  primaryBtn: {
    width: width - 48,
    paddingVertical: 16,
    borderRadius: 14,
    alignItems: 'center',
    marginBottom: 16,
  },
  primaryBtnText: { color: '#fff', fontWeight: '800', fontSize: 16 },
  wordGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    width: '100%',
    gap: 10,
    marginBottom: 20,
    justifyContent: 'center',
  },
  wordCard: {
    width: (width - 68) / 3,
    backgroundColor: '#111827',
    borderRadius: 10,
    paddingVertical: 10,
    paddingHorizontal: 8,
    borderWidth: 1,
    borderColor: '#1E2D4A',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  wordNum: { color: '#4A5B7A', fontSize: 11, fontWeight: '700', width: 16 },
  wordText: { color: '#E0EAFF', fontSize: 13, fontWeight: '600' },
  copyBtn: {
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 12,
    borderWidth: 1.5,
    borderColor: '#14F195',
    marginBottom: 20,
  },
  copyBtnText: { color: '#14F195', fontWeight: '700', fontSize: 14 },
  dangerBox: {
    width: '100%',
    backgroundColor: '#1A0A0A',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#3A1515',
    marginBottom: 28,
  },
  dangerText: { color: '#FF6B6B', fontSize: 13, lineHeight: 20, textAlign: 'center' },
});
