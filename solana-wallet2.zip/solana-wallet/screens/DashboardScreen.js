import React, { useEffect, useRef, useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet,
  ScrollView, RefreshControl, Animated, Alert, Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import * as Clipboard from 'expo-clipboard';
import { useWallet } from '../context/WalletContext';

const { width } = Dimensions.get('window');

function shortAddress(addr) {
  if (!addr) return '';
  const s = addr.toString();
  return `${s.slice(0, 6)}...${s.slice(-4)}`;
}

function timeAgo(unix) {
  if (!unix) return 'Pending';
  const diff = Date.now() / 1000 - unix;
  if (diff < 60) return 'Just now';
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}

export default function DashboardScreen({ navigation }) {
  const { wallet, balance, transactions, refreshBalance, fetchTransactions, clearWallet } = useWallet();
  const [refreshing, setRefreshing] = useState(false);
  const [copied, setCopied] = useState(false);
  const balanceAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(balanceAnim, { toValue: 1, duration: 800, useNativeDriver: true }).start();
  }, [balance]);

  const onRefresh = async () => {
    setRefreshing(true);
    await Promise.all([refreshBalance(), fetchTransactions()]);
    setRefreshing(false);
  };

  const copyAddress = async () => {
    if (!wallet) return;
    await Clipboard.setStringAsync(wallet.publicKey.toString());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleLogout = () => {
    Alert.alert(
      'Remove Wallet',
      'This will delete your wallet from this device. Make sure you have your seed phrase saved.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Remove',
          style: 'destructive',
          onPress: async () => { await clearWallet(); navigation.replace('Welcome'); },
        },
      ]
    );
  };

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#080B14', '#0D1628', '#080B14']} style={StyleSheet.absoluteFill} />

      <ScrollView
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#9945FF" />}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scroll}
      >
        {/* Top bar */}
        <View style={styles.topBar}>
          <View style={styles.networkBadge}>
            <View style={styles.networkDot} />
            <Text style={styles.networkText}>Mainnet</Text>
          </View>
          <TouchableOpacity onPress={handleLogout} style={styles.menuBtn}>
            <Text style={styles.menuIcon}>⋯</Text>
          </TouchableOpacity>
        </View>

        {/* Balance card */}
        <LinearGradient
          colors={['#12102A', '#0E1A2E']}
          style={styles.balanceCard}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        >
          <View style={styles.cardGlow} />
          <Text style={styles.balanceLabel}>Total Balance</Text>
          <Animated.Text style={[styles.balanceValue, { opacity: balanceAnim }]}>
            {balance === null ? '—' : `${balance.toFixed(4)}`}
            <Text style={styles.balanceCurrency}>  SOL</Text>
          </Animated.Text>

          {/* Address */}
          <TouchableOpacity style={styles.addressRow} onPress={copyAddress} activeOpacity={0.7}>
            <Text style={styles.addressText}>
              {wallet ? shortAddress(wallet.publicKey.toString()) : ''}
            </Text>
            <Text style={styles.copyIcon}>{copied ? '✓' : '⎘'}</Text>
          </TouchableOpacity>
        </LinearGradient>

        {/* Action buttons */}
        <View style={styles.actions}>
          <TouchableOpacity
            style={styles.actionBtn}
            onPress={() => navigation.navigate('Send')}
            activeOpacity={0.8}
          >
            <LinearGradient colors={['#9945FF22', '#9945FF11']} style={styles.actionGradient}>
              <Text style={styles.actionIcon}>↑</Text>
              <Text style={styles.actionLabel}>Send</Text>
            </LinearGradient>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.actionBtn}
            onPress={() => navigation.navigate('Receive')}
            activeOpacity={0.8}
          >
            <LinearGradient colors={['#14F19522', '#14F19511']} style={styles.actionGradient}>
              <Text style={[styles.actionIcon, { color: '#14F195' }]}>↓</Text>
              <Text style={[styles.actionLabel, { color: '#14F195' }]}>Receive</Text>
            </LinearGradient>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.actionBtn}
            onPress={onRefresh}
            activeOpacity={0.8}
          >
            <LinearGradient colors={['#00C2FF22', '#00C2FF11']} style={styles.actionGradient}>
              <Text style={[styles.actionIcon, { color: '#00C2FF', fontSize: 20 }]}>↻</Text>
              <Text style={[styles.actionLabel, { color: '#00C2FF' }]}>Refresh</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>

        {/* Transactions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Recent Activity</Text>

          {transactions.length === 0 ? (
            <View style={styles.emptyTx}>
              <Text style={styles.emptyIcon}>◎</Text>
              <Text style={styles.emptyText}>No transactions yet</Text>
            </View>
          ) : (
            transactions.slice(0, 15).map((tx, i) => (
              <View key={tx.signature} style={styles.txRow}>
                <View style={[styles.txIcon, { backgroundColor: tx.err ? '#1A0A0A' : '#0A1A0E' }]}>
                  <Text style={{ fontSize: 16 }}>{tx.err ? '✗' : '✓'}</Text>
                </View>
                <View style={styles.txInfo}>
                  <Text style={styles.txSig}>{shortAddress(tx.signature)}</Text>
                  <Text style={styles.txTime}>{timeAgo(tx.blockTime)}</Text>
                </View>
                <View style={[styles.txStatus, { backgroundColor: tx.err ? '#3A1515' : '#0A2A18' }]}>
                  <Text style={[styles.txStatusText, { color: tx.err ? '#FF6B6B' : '#14F195' }]}>
                    {tx.err ? 'Failed' : 'Success'}
                  </Text>
                </View>
              </View>
            ))
          )}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#080B14' },
  scroll: { paddingBottom: 40 },
  topBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 56,
    paddingBottom: 16,
  },
  networkBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: '#111827', paddingHorizontal: 12, paddingVertical: 6,
    borderRadius: 20, borderWidth: 1, borderColor: '#1E2D4A',
  },
  networkDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: '#14F195' },
  networkText: { color: '#A0B0CC', fontSize: 12, fontWeight: '600' },
  menuBtn: { padding: 8 },
  menuIcon: { color: '#7A90B8', fontSize: 22 },
  balanceCard: {
    marginHorizontal: 20,
    borderRadius: 24,
    padding: 28,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#1E2D4A',
    overflow: 'hidden',
    position: 'relative',
  },
  cardGlow: {
    position: 'absolute', top: -40, right: -40,
    width: 160, height: 160, borderRadius: 80,
    backgroundColor: '#9945FF', opacity: 0.06,
  },
  balanceLabel: { color: '#6B7FA3', fontSize: 13, fontWeight: '600', letterSpacing: 1, marginBottom: 8 },
  balanceValue: { color: '#FFFFFF', fontSize: 44, fontWeight: '900', letterSpacing: -1 },
  balanceCurrency: { fontSize: 20, color: '#9945FF', fontWeight: '700' },
  addressRow: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    backgroundColor: '#080B14', borderRadius: 10, paddingHorizontal: 12,
    paddingVertical: 8, alignSelf: 'flex-start', marginTop: 16,
    borderWidth: 1, borderColor: '#1E2D4A',
  },
  addressText: { color: '#7A90B8', fontSize: 13, fontFamily: 'monospace' },
  copyIcon: { color: '#9945FF', fontSize: 14 },
  actions: { flexDirection: 'row', paddingHorizontal: 20, gap: 12, marginBottom: 28 },
  actionBtn: { flex: 1, borderRadius: 16, overflow: 'hidden', borderWidth: 1, borderColor: '#1E2D4A' },
  actionGradient: { alignItems: 'center', paddingVertical: 18, gap: 6 },
  actionIcon: { fontSize: 24, color: '#9945FF', fontWeight: '700' },
  actionLabel: { color: '#9945FF', fontSize: 12, fontWeight: '700' },
  section: { paddingHorizontal: 20 },
  sectionTitle: { color: '#E0EAFF', fontSize: 16, fontWeight: '800', marginBottom: 16 },
  emptyTx: { alignItems: 'center', paddingVertical: 40, gap: 12 },
  emptyIcon: { fontSize: 40, color: '#1E2D4A' },
  emptyText: { color: '#3A4A63', fontSize: 14 },
  txRow: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    backgroundColor: '#111827', borderRadius: 14, padding: 14,
    marginBottom: 8, borderWidth: 1, borderColor: '#1E2D4A',
  },
  txIcon: { width: 36, height: 36, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  txInfo: { flex: 1 },
  txSig: { color: '#A0B0CC', fontSize: 13, fontFamily: 'monospace', marginBottom: 2 },
  txTime: { color: '#4A5B7A', fontSize: 11 },
  txStatus: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  txStatusText: { fontSize: 11, fontWeight: '700' },
});
