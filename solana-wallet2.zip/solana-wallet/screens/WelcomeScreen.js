import React, { useEffect, useRef } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet,
  Animated, Dimensions, Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useWallet } from '../context/WalletContext';

const { width, height } = Dimensions.get('window');

export default function WelcomeScreen({ navigation }) {
  const { wallet } = useWallet();
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(40)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    // If wallet exists, skip to dashboard
    if (wallet) {
      navigation.replace('Dashboard');
      return;
    }

    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 1000, useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 0, duration: 800, useNativeDriver: true }),
    ]).start();

    // Pulse animation for logo
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.08, duration: 2000, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1, duration: 2000, useNativeDriver: true }),
      ])
    ).start();
  }, [wallet]);

  return (
    <View style={styles.container}>
      {/* Background gradient */}
      <LinearGradient
        colors={['#080B14', '#0D1628', '#080B14']}
        style={StyleSheet.absoluteFill}
      />

      {/* Glow orb */}
      <View style={styles.glowOrb} />

      <Animated.View style={[styles.content, { opacity: fadeAnim, transform: [{ translateY: slideAnim }] }]}>
        {/* Logo */}
        <Animated.View style={[styles.logoContainer, { transform: [{ scale: pulseAnim }] }]}>
          <LinearGradient
            colors={['#9945FF', '#14F195']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.logoGradient}
          >
            <Text style={styles.logoIcon}>◎</Text>
          </LinearGradient>
        </Animated.View>

        <Text style={styles.appName}>SOLFLUX</Text>
        <Text style={styles.tagline}>Your Solana. Your Keys. Your Rules.</Text>

        {/* Features */}
        <View style={styles.features}>
          {['Non-custodial & secure', 'Send & receive SOL instantly', 'Full transaction history'].map((f, i) => (
            <View key={i} style={styles.featureRow}>
              <Text style={styles.featureDot}>◈</Text>
              <Text style={styles.featureText}>{f}</Text>
            </View>
          ))}
        </View>

        {/* CTA Buttons */}
        <TouchableOpacity onPress={() => navigation.navigate('CreateWallet')} activeOpacity={0.85}>
          <LinearGradient
            colors={['#9945FF', '#14F195']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={styles.primaryBtn}
          >
            <Text style={styles.primaryBtnText}>Create New Wallet</Text>
          </LinearGradient>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.secondaryBtn}
          onPress={() => navigation.navigate('ImportWallet')}
          activeOpacity={0.85}
        >
          <Text style={styles.secondaryBtnText}>Import Existing Wallet</Text>
        </TouchableOpacity>

        <Text style={styles.disclaimer}>
          Self-custody wallet. Your seed phrase is never sent anywhere.
        </Text>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#080B14' },
  glowOrb: {
    position: 'absolute',
    top: height * 0.1,
    alignSelf: 'center',
    width: 300,
    height: 300,
    borderRadius: 150,
    backgroundColor: '#9945FF',
    opacity: 0.08,
    shadowColor: '#9945FF',
    shadowRadius: 80,
    shadowOpacity: 1,
  },
  content: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 28,
  },
  logoContainer: {
    marginBottom: 24,
    shadowColor: '#9945FF',
    shadowRadius: 20,
    shadowOpacity: 0.6,
    elevation: 20,
  },
  logoGradient: {
    width: 80,
    height: 80,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoIcon: { fontSize: 40, color: '#fff' },
  appName: {
    fontSize: 36,
    fontWeight: '900',
    color: '#FFFFFF',
    letterSpacing: 8,
    marginBottom: 8,
  },
  tagline: {
    fontSize: 14,
    color: '#6B7FA3',
    marginBottom: 40,
    letterSpacing: 0.5,
  },
  features: { width: '100%', marginBottom: 44, gap: 12 },
  featureRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  featureDot: { color: '#14F195', fontSize: 14 },
  featureText: { color: '#A0B0CC', fontSize: 14 },
  primaryBtn: {
    width: width - 56,
    paddingVertical: 16,
    borderRadius: 14,
    alignItems: 'center',
    marginBottom: 14,
  },
  primaryBtnText: { color: '#fff', fontWeight: '800', fontSize: 16, letterSpacing: 0.5 },
  secondaryBtn: {
    width: width - 56,
    paddingVertical: 16,
    borderRadius: 14,
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: '#1E2D4A',
    marginBottom: 32,
  },
  secondaryBtnText: { color: '#7A90B8', fontWeight: '600', fontSize: 16 },
  disclaimer: { color: '#3A4A63', fontSize: 12, textAlign: 'center', lineHeight: 18 },
});
