import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  Alert, ActivityIndicator, Dimensions, KeyboardAvoidingView,
  Platform, ScrollView,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useWallet } from '../context/WalletContext';

const { width } = Dimensions.get('window');

export default function SendScreen({ navigation }) {
  const { sendSOL, balance, loading } = useWallet();
  const [toAddress, setToAddress] = useState('');
  const [amount, setAmount] = useState('');
  const [txSig, setTxSig] = useState(null);

  const handleSend = async () => {
    const amt = parseFloat(amount);
    if (!toAddress.trim() || toAddress.trim().length < 32) {
      Alert.alert('Invalid Address', 'Please enter a valid Solana address');
      return;
    }
    if (isNaN(amt) || amt <= 0) {
      Alert.alert('Invalid Amount', 'Please enter a valid SOL amount');
      return;
    }
    if (amt > (balance || 0)) {
      Alert.alert('Insufficient Balance', `You only have ${balance?.toFixed(4)} SOL`);
      return;
    }

    const fee = (amt * 0.01).toFixed(6);
    const recipient = (amt * 0.99).toFixed(6);

    Alert.alert(
      'Confirm Transaction',
      `Send ${amt} SOL to\n${toAddress.slice(0, 16)}...${toAddress.slice(-8)}\n\nRecipient gets: ${recipient} SOL\nNetwork fee: ~0.000005 SOL\nApp fee (1%): ${fee} SOL`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Send',
          onPress: async () => {
            try {
              const sig = await sendSOL(toAddress.trim(), amt);
              setTxSig(sig);
            } catch (e) {
              Alert.alert('Transaction Failed', e.message);
            }
          },
        },
      ]
    );
  };

  if (txSig) {
    return (
      <View style={styles.container}>
        <LinearGradient colors={['#080B14', '#0D1628', '#080B14']} style={StyleSheet.absoluteFill} />
        <View style={styles.successContainer}>
          <View style={styles.successIcon}>
            <LinearGradient colors={['#14F195', '#009B60']} style={styles.successGrad}>
              <Text style={{ fontSize: 36 }}>✓</Text>
            </LinearGradient>
          </View>
          <Text style={styles.successTitle}>Sent!</Text>
          <Text style={styles.successSubtitle}>Your transaction was submitted to the network.</Text>
          <View style={styles.sigBox}>
            <Text style={styles.sigLabel}>Transaction Signature</Text>
            <Text style={styles.sigValue} numberOfLines={2} selectable>{txSig}</Text>
          </View>
          <TouchableOpacity onPress={() => navigation.goBack()} activeOpacity={0.85} style={{ width: '100%' }}>
            <LinearGradient
              colors={['#9945FF', '#14F195']}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
              style={styles.primaryBtn}
            >
              <Text style={styles.primaryBtnText}>Back to Wallet</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <View style={styles.container}>
        <LinearGradient colors={['#080B14', '#0D1628', '#080B14']} style={StyleSheet.absoluteFill} />

        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
            <Text style={styles.backText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Send SOL</Text>
          <View style={{ width: 60 }} />
        </View>

        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
          {/* Balance display */}
          <View style={styles.balancePill}>
            <Text style={styles.balancePillLabel}>Available:</Text>
            <Text style={styles.balancePillValue}>{balance?.toFixed(4) ?? '—'} SOL</Text>
          </View>

          <Text style={styles.label}>Recipient Address</Text>
          <TextInput
            style={styles.input}
            value={toAddress}
            onChangeText={setToAddress}
            placeholder="Enter Solana wallet address..."
            placeholderTextColor="#3A4A63"
            autoCapitalize="none"
            autoCorrect={false}
          />

          <Text style={styles.label}>Amount (SOL)</Text>
          <View style={styles.amountRow}>
            <TextInput
              style={[styles.input, { flex: 1 }]}
              value={amount}
              onChangeText={setAmount}
              placeholder="0.00"
              placeholderTextColor="#3A4A63"
              keyboardType="decimal-pad"
            />
            <TouchableOpacity
              style={styles.maxBtn}
              onPress={() => {
                const max = Math.max(0, (balance || 0) - 0.000005); // reserve for fee
                setAmount(max.toFixed(6));
              }}
            >
              <Text style={styles.maxBtnText}>MAX</Text>
            </TouchableOpacity>
          </View>

          {/* Fee note */}
          <View style={styles.feeNote}>
            <Text style={styles.feeText}>⛽ Network fee ≈ 0.000005 SOL  •  App fee: 1%</Text>
          </View>

          <TouchableOpacity onPress={handleSend} disabled={loading} activeOpacity={0.85}>
            <LinearGradient
              colors={['#9945FF', '#14F195']}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
              style={styles.primaryBtn}
            >
              {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.primaryBtnText}>Send SOL →</Text>}
            </LinearGradient>
          </TouchableOpacity>
        </ScrollView>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#080B14' },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 20, paddingTop: 56, paddingBottom: 16,
  },
  backBtn: { padding: 8 },
  backText: { color: '#7A90B8', fontSize: 15 },
  headerTitle: { color: '#fff', fontSize: 17, fontWeight: '700' },
  content: { paddingHorizontal: 24, paddingBottom: 40 },
  balancePill: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    backgroundColor: '#111827', borderRadius: 12, padding: 14,
    borderWidth: 1, borderColor: '#1E2D4A', marginBottom: 28, alignSelf: 'flex-start',
  },
  balancePillLabel: { color: '#6B7FA3', fontSize: 13 },
  balancePillValue: { color: '#14F195', fontSize: 14, fontWeight: '700' },
  label: { color: '#A0B0CC', fontSize: 13, fontWeight: '600', marginBottom: 8, letterSpacing: 0.5 },
  input: {
    backgroundColor: '#111827', borderRadius: 14, padding: 16,
    color: '#E0EAFF', fontSize: 14, borderWidth: 1.5, borderColor: '#1E2D4A',
    marginBottom: 20,
  },
  amountRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 0 },
  maxBtn: {
    backgroundColor: '#1E2D4A', borderRadius: 10, paddingHorizontal: 14,
    paddingVertical: 16, marginBottom: 20,
  },
  maxBtnText: { color: '#9945FF', fontWeight: '800', fontSize: 13 },
  feeNote: {
    backgroundColor: '#0A1628', borderRadius: 10, padding: 12,
    borderWidth: 1, borderColor: '#1A2E50', marginBottom: 28,
  },
  feeText: { color: '#5A7FA0', fontSize: 12, textAlign: 'center' },
  primaryBtn: { width: '100%', paddingVertical: 16, borderRadius: 14, alignItems: 'center' },
  primaryBtnText: { color: '#fff', fontWeight: '800', fontSize: 16 },
  successContainer: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 28 },
  successIcon: { marginBottom: 24, shadowColor: '#14F195', shadowRadius: 20, shadowOpacity: 0.5 },
  successGrad: { width: 80, height: 80, borderRadius: 40, alignItems: 'center', justifyContent: 'center' },
  successTitle: { color: '#fff', fontSize: 32, fontWeight: '900', marginBottom: 12 },
  successSubtitle: { color: '#6B7FA3', fontSize: 14, textAlign: 'center', marginBottom: 28 },
  sigBox: {
    width: '100%', backgroundColor: '#111827', borderRadius: 14, padding: 16,
    borderWidth: 1, borderColor: '#1E2D4A', marginBottom: 32,
  },
  sigLabel: { color: '#4A5B7A', fontSize: 11, fontWeight: '600', marginBottom: 8 },
  sigValue: { color: '#A0B0CC', fontSize: 11, fontFamily: 'monospace', lineHeight: 18 },
});
