import React, { useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet,
  Dimensions, Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import * as Clipboard from 'expo-clipboard';
import { useWallet } from '../context/WalletContext';

const { width } = Dimensions.get('window');

export default function ReceiveScreen({ navigation }) {
  const { wallet } = useWallet();
  const [copied, setCopied] = useState(false);
  const address = wallet?.publicKey?.toString() || '';

  const copyAddress = async () => {
    await Clipboard.setStringAsync(address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Generate a simple visual address grid as placeholder (real app would use react-native-qrcode-svg)
  const chunks = address.match(/.{1,8}/g) || [];

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#080B14', '#0D1628', '#080B14']} style={StyleSheet.absoluteFill} />

      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Receive SOL</Text>
        <View style={{ width: 60 }} />
      </View>

      <View style={styles.content}>
        <Text style={styles.subtitle}>Share your address to receive SOL</Text>

        {/* QR placeholder - in prod use react-native-qrcode-svg */}
        <View style={styles.qrContainer}>
          <LinearGradient
            colors={['#9945FF33', '#14F19522']}
            style={styles.qrGrad}
            start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
          >
            <View style={styles.qrInner}>
              {/* Visual grid representation */}
              <View style={styles.qrGrid}>
                {chunks.map((chunk, i) => (
                  <View key={i} style={styles.qrRow}>
                    {chunk.split('').map((char, j) => (
                      <View
                        key={j}
                        style={[
                          styles.qrCell,
                          { backgroundColor: (char.charCodeAt(0) % 2 === 0) ? '#9945FF' : '#14F195', opacity: 0.6 + (char.charCodeAt(0) % 4) * 0.1 }
                        ]}
                      />
                    ))}
                  </View>
                ))}
              </View>
              <Text style={styles.qrNote}>◎ SOL</Text>
            </View>
          </LinearGradient>
          <Text style={styles.qrHint}>
            💡 Install react-native-qrcode-svg for real QR codes
          </Text>
        </View>

        {/* Address */}
        <View style={styles.addressCard}>
          <Text style={styles.addressLabel}>Your Wallet Address</Text>
          <Text style={styles.addressValue} selectable numberOfLines={2}>{address}</Text>
        </View>

        <TouchableOpacity onPress={copyAddress} activeOpacity={0.85} style={{ width: '100%' }}>
          <LinearGradient
            colors={copied ? ['#14F195', '#009B60'] : ['#9945FF', '#14F195']}
            start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
            style={styles.copyBtn}
          >
            <Text style={styles.copyBtnText}>{copied ? '✓ Address Copied!' : '⎘  Copy Address'}</Text>
          </LinearGradient>
        </TouchableOpacity>

        <View style={styles.networkNote}>
          <Text style={styles.networkNoteText}>
            ⚠️ Only send SOL and Solana SPL tokens to this address
          </Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#080B14' },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 20, paddingTop: 56, paddingBottom: 16,
  },
  backBtn: { padding: 8 },
  backText: { color: '#7A90B8', fontSize: 15 },
  headerTitle: { color: '#fff', fontSize: 17, fontWeight: '700' },
  content: { flex: 1, paddingHorizontal: 24, alignItems: 'center', paddingTop: 8 },
  subtitle: { color: '#6B7FA3', fontSize: 14, marginBottom: 28 },
  qrContainer: { alignItems: 'center', marginBottom: 28 },
  qrGrad: { borderRadius: 24, padding: 3 },
  qrInner: {
    backgroundColor: '#080B14', borderRadius: 22, padding: 20,
    alignItems: 'center', justifyContent: 'center',
  },
  qrGrid: { gap: 2, marginBottom: 12 },
  qrRow: { flexDirection: 'row', gap: 2 },
  qrCell: { width: 10, height: 10, borderRadius: 2 },
  qrNote: { color: '#9945FF', fontSize: 16, fontWeight: '800' },
  qrHint: { color: '#3A4A63', fontSize: 11, marginTop: 10, textAlign: 'center' },
  addressCard: {
    width: '100%', backgroundColor: '#111827', borderRadius: 16,
    padding: 18, borderWidth: 1, borderColor: '#1E2D4A', marginBottom: 20,
  },
  addressLabel: { color: '#4A5B7A', fontSize: 11, fontWeight: '600', marginBottom: 8, letterSpacing: 1 },
  addressValue: {
    color: '#A0B0CC', fontSize: 13, fontFamily: 'monospace',
    lineHeight: 20, letterSpacing: 0.5,
  },
  copyBtn: {
    width: '100%', paddingVertical: 16, borderRadius: 14, alignItems: 'center', marginBottom: 16,
  },
  copyBtnText: { color: '#fff', fontWeight: '800', fontSize: 16 },
  networkNote: {
    backgroundColor: '#0A1A0A', borderRadius: 12, padding: 14,
    borderWidth: 1, borderColor: '#0E2A18', width: '100%',
  },
  networkNoteText: { color: '#5A8A6A', fontSize: 12, textAlign: 'center', lineHeight: 18 },
});
