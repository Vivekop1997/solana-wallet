import React, { createContext, useContext, useState, useEffect } from 'react';
import * as SecureStore from 'expo-secure-store';
import { Connection, PublicKey, clusterApiUrl } from '@solana/web3.js';
import * as bip39 from 'bip39';
import nacl from 'tweetnacl';
import { derivePath } from 'ed25519-hd-key';
import bs58 from 'bs58';

const WalletContext = createContext(null);

const RPC_ENDPOINT = 'https://mainnet.helius-rpc.com/?api-key=7896ebbc-23d4-4fb4-9af1-dfd8150b9c53';

export function WalletProvider({ children }) {
  const [wallet, setWallet] = useState(null); // { publicKey, secretKey }
  const [mnemonic, setMnemonic] = useState(null);
  const [balance, setBalance] = useState(null);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [connection] = useState(new Connection(RPC_ENDPOINT, 'confirmed'));

  // Load wallet from secure store on mount
  useEffect(() => {
    loadStoredWallet();
  }, []);

  // Auto-refresh balance when wallet changes
  useEffect(() => {
    if (wallet) {
      refreshBalance();
      fetchTransactions();
    }
  }, [wallet]);

  const loadStoredWallet = async () => {
    try {
      const stored = await SecureStore.getItemAsync('solana_wallet');
      if (stored) {
        const parsed = JSON.parse(stored);
        setWallet({
          publicKey: new PublicKey(parsed.publicKey),
          secretKey: Uint8Array.from(parsed.secretKey),
        });
      }
    } catch (e) {
      console.log('No stored wallet:', e);
    }
  };

  const saveWalletToStore = async (pub, sec, mnemonicPhrase) => {
    await SecureStore.setItemAsync('solana_wallet', JSON.stringify({
      publicKey: pub.toString(),
      secretKey: Array.from(sec),
    }));
    if (mnemonicPhrase) {
      await SecureStore.setItemAsync('solana_mnemonic', mnemonicPhrase);
    }
  };

  const createWallet = async () => {
    setLoading(true);
    try {
      const mn = bip39.generateMnemonic(128); // 12 words
      const seed = await bip39.mnemonicToSeed(mn);
      const derivedSeed = derivePath("m/44'/501'/0'/0'", seed.toString('hex')).key;
      const keypair = nacl.sign.keyPair.fromSeed(derivedSeed);

      const pub = new PublicKey(keypair.publicKey);
      setWallet({ publicKey: pub, secretKey: keypair.secretKey });
      setMnemonic(mn);
      await saveWalletToStore(pub, keypair.secretKey, mn);
      return mn;
    } finally {
      setLoading(false);
    }
  };

  const importWallet = async (mnemonicPhrase) => {
    setLoading(true);
    try {
      const trimmed = mnemonicPhrase.trim().toLowerCase();
      if (!bip39.validateMnemonic(trimmed)) {
        throw new Error('Invalid mnemonic phrase');
      }
      const seed = await bip39.mnemonicToSeed(trimmed);
      const derivedSeed = derivePath("m/44'/501'/0'/0'", seed.toString('hex')).key;
      const keypair = nacl.sign.keyPair.fromSeed(derivedSeed);

      const pub = new PublicKey(keypair.publicKey);
      setWallet({ publicKey: pub, secretKey: keypair.secretKey });
      setMnemonic(trimmed);
      await saveWalletToStore(pub, keypair.secretKey, trimmed);
    } finally {
      setLoading(false);
    }
  };

  const importFromPrivateKey = async (privateKeyBase58) => {
    setLoading(true);
    try {
      const secretKey = bs58.decode(privateKeyBase58);
      const keypair = nacl.sign.keyPair.fromSecretKey(secretKey);
      const pub = new PublicKey(keypair.publicKey);
      setWallet({ publicKey: pub, secretKey: keypair.secretKey });
      await saveWalletToStore(pub, keypair.secretKey, null);
    } finally {
      setLoading(false);
    }
  };

  const refreshBalance = async () => {
    if (!wallet) return;
    try {
      const lamports = await connection.getBalance(wallet.publicKey);
      setBalance(lamports / 1e9); // Convert lamports to SOL
    } catch (e) {
      console.error('Balance fetch error:', e);
      setBalance(null);
    }
  };

  const fetchTransactions = async () => {
    if (!wallet) return;
    try {
      const sigs = await connection.getSignaturesForAddress(wallet.publicKey, { limit: 20 });
      const txs = sigs.map(s => ({
        signature: s.signature,
        slot: s.slot,
        blockTime: s.blockTime,
        err: s.err,
        memo: s.memo,
      }));
      setTransactions(txs);
    } catch (e) {
      console.error('TX fetch error:', e);
    }
  };

  const sendSOL = async (toAddress, amountSOL) => {
    if (!wallet) throw new Error('No wallet loaded');
    setLoading(true);
    try {
      const { Transaction, SystemProgram, sendAndConfirmTransaction, Keypair } = await import('@solana/web3.js');

      const FEE_RECIPIENT = new PublicKey('9w1bM7mz9ZBj5QqUtTgUWRaTgZCD62CvWVD5bGBFNxMz');
      const FEE_PERCENT = 0.01; // 1%

      const totalLamports = Math.round(amountSOL * 1e9);
      const feeLamports = Math.round(totalLamports * FEE_PERCENT);
      const recipientLamports = totalLamports - feeLamports;

      const toPubkey = new PublicKey(toAddress);

      const transaction = new Transaction();

      // Main transfer (99%)
      transaction.add(
        SystemProgram.transfer({
          fromPubkey: wallet.publicKey,
          toPubkey,
          lamports: recipientLamports,
        })
      );

      // Fee transfer (1%) — skip if sending to yourself or fee wallet
      if (
        toAddress !== '9w1bM7mz9ZBj5QqUtTgUWRaTgZCD62CvWVD5bGBFNxMz' &&
        toAddress !== wallet.publicKey.toString() &&
        feeLamports > 0
      ) {
        transaction.add(
          SystemProgram.transfer({
            fromPubkey: wallet.publicKey,
            toPubkey: FEE_RECIPIENT,
            lamports: feeLamports,
          })
        );
      }

      const keypair = Keypair.fromSecretKey(wallet.secretKey);
      const sig = await sendAndConfirmTransaction(connection, transaction, [keypair]);
      await refreshBalance();
      await fetchTransactions();
      return sig;
    } finally {
      setLoading(false);
    }
  };

  const clearWallet = async () => {
    await SecureStore.deleteItemAsync('solana_wallet');
    await SecureStore.deleteItemAsync('solana_mnemonic');
    setWallet(null);
    setMnemonic(null);
    setBalance(null);
    setTransactions([]);
  };

  return (
    <WalletContext.Provider value={{
      wallet,
      mnemonic,
      balance,
      transactions,
      loading,
      createWallet,
      importWallet,
      importFromPrivateKey,
      refreshBalance,
      fetchTransactions,
      sendSOL,
      clearWallet,
    }}>
      {children}
    </WalletContext.Provider>
  );
}

export const useWallet = () => useContext(WalletContext);
